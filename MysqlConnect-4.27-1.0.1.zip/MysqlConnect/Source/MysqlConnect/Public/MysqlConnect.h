// Copyright 2021 ShuoDun. All Rights Reserved.

#pragma once

#include "Modules/ModuleManager.h"

class FMysqlConnectModule : public IModuleInterface
{
public:
	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

public:
	static inline FMysqlConnectModule& Get()
	{
		return FModuleManager::LoadModuleChecked<FMysqlConnectModule>("MysqlConnect");
	}

	static inline bool IsAvailable()
	{
		return FModuleManager::Get().IsModuleLoaded("MysqlConnect");
	}

private:

};
