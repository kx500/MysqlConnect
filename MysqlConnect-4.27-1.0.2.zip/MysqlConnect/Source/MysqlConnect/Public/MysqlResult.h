// Copyright 2021 ShuoDun. All Rights Reserved.
#pragma once

#include <string>
#include <map>
#include "MysqlResult.generated.h"


USTRUCT(BlueprintType)
struct FRow
{
	GENERATED_BODY()
	/** һ�е����� */
	UPROPERTY(BlueprintReadWrite, Category = "Reult Row Value")
		TMap<FString, FString> Value;
};


UCLASS(BlueprintType, Blueprintable)
class MYSQLCONNECT_API UMysqlResult : public UObject
{
	GENERATED_UCLASS_BODY()

public:
	FString Msg;

	bool IsSucceed;

	int effectRows;

	int insert_id;

	TArray<FRow> rows;

public:
	void Reset();
	void setRows(std::map<int, std::map<std::string, std::string>> arr);

public:
	UFUNCTION(BlueprintCallable, Category = "Mysql|Result")
		FString getMsg();

	UFUNCTION(BlueprintCallable, Category = "Mysql|Result")
		bool getState();

	UFUNCTION(BlueprintCallable, Category = "Mysql|Result")
		int getCount();

	UFUNCTION(BlueprintCallable, Category = "Mysql|Result")
		int getEffectRows();

	UFUNCTION(BlueprintCallable, Category = "Mysql|Result")
		int getInsertId();

	UFUNCTION(BlueprintCallable, Category = "Mysql|Result")
		TArray<FRow> getRows();

};
