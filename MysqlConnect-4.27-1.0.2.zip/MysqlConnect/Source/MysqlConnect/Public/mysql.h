// Copyright 2021 ShuoDun. All Rights Reserved.

#if defined _WIN32 || defined _WIN64
#define EXAMPLELIBRARY_IMPORT __declspec(dllimport)
#elif defined __linux__
#define EXAMPLELIBRARY_IMPORT __attribute__((visibility("default")))
#else
#define EXAMPLELIBRARY_IMPORT
#endif

#include <string>
#include <map>
#include <list>

#define CPPCONN_LIB_BUILD

using namespace std;

namespace sql
{
	class Driver;
	class Connection;

	class MysqlApi
	{
	public:
		Driver* driver;
		Connection* con;

	public:
		void init();
		void close();
		bool Connect(string Host, int Port, string UserName, string Password, string DbName, string& msg);

		// ִ��MYSQL����
		bool Execute(string Sql, string& msg);

		// executeUpdate������UPDATE  INSERT  DELETE����
		bool Update(string Sql, string& msg, int& ret);

		// executeQuery������ SELECT
		bool Query(string Sql, string& msg, map<int, map<string, string>>& Results);

	};
};