// Copyright 2021 ShuoDun. All Rights Reserved.

#pragma once

#include "Subsystems/EngineSubsystem.h"
#include "ClientLatentAction.h"
#include "mysql.h"
#include "WorkerThread.h"
#include "MysqlResult.h"
#include "MysqlConnectSubsystem.generated.h"

using namespace sql;

class UMysqlResult;

UCLASS()
class MYSQLCONNECT_API UMysqlConnectSubsystem : public UEngineSubsystem
{
	GENERATED_BODY()

public:
	UMysqlConnectSubsystem();

	// Begin USubsystem
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	// End USubsystem

private:
	void UseAsync(UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, UMysqlResult*& Results);

protected:
	MysqlApi Mysql;

	/** Latent action helper */
	FClientLatentAction<UMysqlResult*>* ContinueAction;

	/** Response data stored as JSON */
	UPROPERTY()
		UMysqlResult* ResponseJsonObj;

public:
	static UMysqlConnectSubsystem* _StaticClass;
	static UMysqlConnectSubsystem* Get();

	//ͬ��
public:
	UFUNCTION(BlueprintCallable, Category = "Mysql")
		void Close();

	UFUNCTION(BlueprintCallable, Category = "Mysql")
		void Connect(FString Host, int Port, FString UserName, FString Password, FString DbName, UMysqlResult*& Results);

	UFUNCTION(BlueprintCallable, Category = "Mysql")
		void Execute(FString Sql, UMysqlResult*& Results);

	UFUNCTION(BlueprintCallable, Category = "Mysql")
		void Insert(FString Sql, UMysqlResult*& Results);

	UFUNCTION(BlueprintCallable, Category = "Mysql")
		void Update(FString Sql, UMysqlResult*& Results);

	UFUNCTION(BlueprintCallable, Category = "Mysql")
		void Delete(FString Sql, UMysqlResult*& Results);

	UFUNCTION(BlueprintCallable, Category = "Mysql")
		void Query(FString Sql, UMysqlResult*& Results);

	//�첽
public:
	/** Connect to the database */
	UFUNCTION(BlueprintCallable, Category = "Mysql|Async", meta = (Latent, LatentInfo = "LatentInfo", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
		void AConnect(FString Host, int Port, FString UserName, FString Password, FString DbName, UMysqlResult*& Results, UObject* WorldContextObject, struct FLatentActionInfo LatentInfo);

	/** execute SQL command (return only success or failure) */
	UFUNCTION(BlueprintCallable, Category = "Mysql|Async", meta = (Latent, LatentInfo = "LatentInfo", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
		void AExecute(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject, struct FLatentActionInfo LatentInfo);

	/** Insert data, if the entry is successful, it will return an auto-increment ID, if it fails, it will return 0 */
	UFUNCTION(BlueprintCallable, Category = "Mysql|Async", meta = (Latent, LatentInfo = "LatentInfo", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
		void AInsert(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject, struct FLatentActionInfo LatentInfo);

	/** Update data */
	UFUNCTION(BlueprintCallable, Category = "Mysql|Async", meta = (Latent, LatentInfo = "LatentInfo", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
		void AUpdate(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject, struct FLatentActionInfo LatentInfo);

	/** delete data from database */
	UFUNCTION(BlueprintCallable, Category = "Mysql|Async", meta = (Latent, LatentInfo = "LatentInfo", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
		void ADelete(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject, struct FLatentActionInfo LatentInfo);

	/** Query data*/
	UFUNCTION(BlueprintCallable, Category = "Mysql|Async", meta = (Latent, LatentInfo = "LatentInfo", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
		void AQuery(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject, struct FLatentActionInfo LatentInfo);

};
