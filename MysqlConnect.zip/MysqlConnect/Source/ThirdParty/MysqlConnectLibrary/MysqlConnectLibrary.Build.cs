// Fill out your copyright notice in the Description page of Project Settings.

using System.IO;
using UnrealBuildTool;

public class MysqlConnectLibrary : ModuleRules
{
	public MysqlConnectLibrary(ReadOnlyTargetRules Target) : base(Target)
	{
		Type = ModuleType.External;

		PublicAdditionalLibraries.Add("$(PluginDir)/Source/ThirdParty/MysqlConnectLibrary/lib/vs14/mysqlclient.lib");

	}
}
