// Copyright 2021 ShuoDun. All Rights Reserved.

#if defined _WIN32 || defined _WIN64
#define EXAMPLELIBRARY_IMPORT __declspec(dllimport)
#elif defined __linux__
#define EXAMPLELIBRARY_IMPORT __attribute__((visibility("default")))
#else
#define EXAMPLELIBRARY_IMPORT
#endif

#include <string>
#include <map>

using namespace std;

struct MYSQL;
class MysqlApi
{
public:
	MYSQL* Conn;

public:
	void init();
	void close();
	bool Connect(std::string Host, int Port, std::string UserName, std::string Password, std::string DbName);
	bool Query(std::string Sql, map<int, map<std::string, std::string>>& Results);
};
