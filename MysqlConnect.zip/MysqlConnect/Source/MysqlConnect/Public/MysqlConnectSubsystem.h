// Copyright 2021 ShuoDun. All Rights Reserved.

#pragma once

#include "Subsystems/EngineSubsystem.h"
//#include "WorkerThread.h"
//#include "Delegates/DelegateCombinations.h"
#include "mysql.h"
#include "MysqlConnectSubsystem.generated.h"


USTRUCT(BlueprintType)
struct FRow
{
	GENERATED_BODY()
		/** һ�е����� */
	UPROPERTY(BlueprintReadWrite, Category = "Reult Row Value")
		TMap<FString, FString> Value;
};


UCLASS()
class MYSQLCONNECT_API UMysqlConnectSubsystem : public UEngineSubsystem
{
	GENERATED_BODY()

public:
	UMysqlConnectSubsystem();

	// Begin USubsystem
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	// End USubsystem

public:
	MysqlApi Mysql;

public:
	UFUNCTION(BlueprintCallable, Category = "Mysql")
	bool Connect(FString Host, int Port, FString UserName, FString Password, FString DbName);

	UFUNCTION(BlueprintCallable, Category = "Mysql")
	bool Query(FString Sql, TArray<FRow>& Results);

};
