// Copyright 2021 ShuoDun. All Rights Reserved.

#pragma once

#include "Subsystems/EngineSubsystem.h"
#include "ClientLatentAction.h"
#include "mysql.h"
#include "WorkerThread.h"
#include "MysqlConnectSubsystem.generated.h"

using namespace sql;

class UMysqlResult;

USTRUCT(BlueprintType)
struct FRow
{
	GENERATED_BODY()
		/** һ�е����� */
	UPROPERTY(BlueprintReadWrite, Category = "Reult Row Value")
		TMap<FString, FString> Value;
};

UCLASS()
class MYSQLCONNECT_API UMysqlConnectSubsystem : public UEngineSubsystem
{
	GENERATED_BODY()

public:
	UMysqlConnectSubsystem();

	// Begin USubsystem
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	// End USubsystem

public:
	MysqlApi Mysql;

protected:
	/** Latent action helper */
	FClientLatentAction<UMysqlResult*>* ContinueAction;

	/** Response data stored as JSON */
	UPROPERTY()
		UMysqlResult* ResponseJsonObj;

public:
	static UMysqlConnectSubsystem* _StaticClass;
	static UMysqlConnectSubsystem* Get();

	void UseAsync(UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, UMysqlResult*& Results);

public:
	/** Connect to the database */
	UFUNCTION(BlueprintCallable, Category = "Mysql", meta = (Latent, LatentInfo = "LatentInfo", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
		void Connect(FString Host, int Port, FString UserName, FString Password, FString DbName, UMysqlResult*& Results, UObject* WorldContextObject = nullptr, struct FLatentActionInfo LatentInfo = FLatentActionInfo());

	/** execute SQL command (return only success or failure) */
	UFUNCTION(BlueprintCallable, Category = "Mysql", meta = (Latent, LatentInfo = "LatentInfo", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
		void Execute(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject = nullptr, struct FLatentActionInfo LatentInfo = FLatentActionInfo());

	/** Insert data, if the entry is successful, it will return an auto-increment ID, if it fails, it will return 0 */
	UFUNCTION(BlueprintCallable, Category = "Mysql", meta = (Latent, LatentInfo = "LatentInfo", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
		void Insert(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject = nullptr, struct FLatentActionInfo LatentInfo = FLatentActionInfo());

	/** Update data */
	UFUNCTION(BlueprintCallable, Category = "Mysql", meta = (Latent, LatentInfo = "LatentInfo", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
		void Update(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject = nullptr, struct FLatentActionInfo LatentInfo = FLatentActionInfo());

	/** delete data from database */
	UFUNCTION(BlueprintCallable, Category = "Mysql", meta = (Latent, LatentInfo = "LatentInfo", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
		void Delete(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject = nullptr, struct FLatentActionInfo LatentInfo = FLatentActionInfo());

	/** Query data*/
	UFUNCTION(BlueprintCallable, Category = "Mysql", meta = (Latent, LatentInfo = "LatentInfo", HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject"))
		void Query(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject = nullptr, struct FLatentActionInfo LatentInfo = FLatentActionInfo());

		

};
