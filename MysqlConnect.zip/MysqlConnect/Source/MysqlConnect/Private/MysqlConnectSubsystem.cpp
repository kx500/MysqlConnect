// Copyright 2021 ShuoDun. All Rights Reserved.

#include "MysqlConnectSubsystem.h"
#include "MysqlConnect.h"
#include "Async/Async.h"
#include "Subsystems/SubsystemBlueprintLibrary.h"


UMysqlConnectSubsystem::UMysqlConnectSubsystem()
	: UEngineSubsystem()
{

}

void UMysqlConnectSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

}

void UMysqlConnectSubsystem::Deinitialize()
{
	// Do nothing for now
	Super::Deinitialize();
}

bool UMysqlConnectSubsystem::Connect(FString Host, int Port, FString UserName, FString Password, FString DbName)
{
	Mysql.close();
	Mysql.init();

	std::string tHost(TCHAR_TO_UTF8(*Host));
	std::string tUserName(TCHAR_TO_UTF8(*UserName));
	std::string tPassword(TCHAR_TO_UTF8(*Password));
	std::string tDbName(TCHAR_TO_UTF8(*DbName));

	bool rt = Mysql.Connect(tHost, Port, tUserName, tPassword, tDbName);
	if (!rt)
	{
		GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Red, TEXT("Failed to connect"));
	}

	return rt;
}

bool UMysqlConnectSubsystem::Query(FString Sql, TArray<FRow>& Results)
{
	std::string tSql(TCHAR_TO_UTF8(*Sql));
	map<int, map<std::string, std::string>> arr;

	bool rt = Mysql.Query(tSql, arr);
	if (!rt)
	{
		GEngine->AddOnScreenDebugMessage(-1, 10.0f, FColor::Red, TEXT("Failed to Query"));
	}

	map<int, map<std::string, std::string>>::iterator iter;
	for (iter = arr.begin(); iter != arr.end(); ++iter)
	{
		FRow _FRow;
		map<std::string, std::string>::iterator val;
		for (val = iter->second.begin(); val != iter->second.end(); ++val)
		{
			_FRow.Value.Add(val->first.c_str(), val->second.c_str());
		}

		Results.Add(_FRow);
	}

	return rt;
}
