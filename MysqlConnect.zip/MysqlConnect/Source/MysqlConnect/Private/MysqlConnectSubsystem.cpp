// Copyright 2021 ShuoDun. All Rights Reserved.

#include "MysqlConnectSubsystem.h"
#include "MysqlConnect.h"
#include "Async/Async.h"
#include "Subsystems/SubsystemBlueprintLibrary.h"


UMysqlConnectSubsystem* UMysqlConnectSubsystem::_StaticClass = NULL;			//����ָ��

UMysqlConnectSubsystem::UMysqlConnectSubsystem()
	: UEngineSubsystem()
{
	_StaticClass = this;
}

void UMysqlConnectSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

}

void UMysqlConnectSubsystem::Deinitialize()
{
	// Do nothing for now
	Super::Deinitialize();
}

UMysqlConnectSubsystem* UMysqlConnectSubsystem::Get()
{
	return _StaticClass;
}

bool UMysqlConnectSubsystem::Connect(FString Host, int Port, FString UserName, FString Password, FString DbName, FString& msg)
{
	Mysql.close();
	Mysql.init();

	std::string tHost(TCHAR_TO_UTF8(*Host));
	std::string tUserName(TCHAR_TO_UTF8(*UserName));
	std::string tPassword(TCHAR_TO_UTF8(*Password));
	std::string tDbName(TCHAR_TO_UTF8(*DbName));
	std::string _msg;

	if (DbName.IsEmpty())
	{
		msg = "Database name cannot be empty";
		return false;
	}

	bool rt = Mysql.Connect(tHost, Port, tUserName, tPassword, tDbName, _msg);
	if (!rt)
	{
		msg = _msg.c_str();
		UE_LOG(LogTemp, Log, TEXT("Failed to connect"));
	}

	return rt;
}

bool UMysqlConnectSubsystem::Query(FString Sql, TArray<FRow>& Results)
{
	std::string tSql(TCHAR_TO_UTF8(*Sql));
	map<int, map<std::string, std::string>> arr;

	bool rt = Mysql.Query(tSql, arr);
	if (!rt)
	{
		UE_LOG(LogTemp, Log, TEXT("Failed to Query"));
	}

	map<int, map<std::string, std::string>>::iterator iter;
	for (iter = arr.begin(); iter != arr.end(); ++iter)
	{
		FRow _FRow;
		map<std::string, std::string>::iterator val;
		for (val = iter->second.begin(); val != iter->second.end(); ++val)
		{
			_FRow.Value.Add(val->first.c_str(), val->second.c_str());
		}

		Results.Add(_FRow);
	}

	return rt;
}
