// Copyright 2021 ShuoDun. All Rights Reserved.

#include "MysqlResult.h"


UMysqlResult::UMysqlResult(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}


void UMysqlResult::Reset()
{
	Msg = "";
	IsSucceed = false;
	rows.Empty();
}

void UMysqlResult::setRows(std::map<int, std::map<std::string, std::string>> arr)
{
	std::map<int, std::map<std::string, std::string>>::iterator iter;
	for (iter = arr.begin(); iter != arr.end(); ++iter)
	{
		FRow _FRow;
		std::map<std::string, std::string>::iterator val;
		for (val = iter->second.begin(); val != iter->second.end(); ++val)
		{
			_FRow.Value.Add(val->first.c_str(), val->second.c_str());
		}

		rows.Add(_FRow);
	}
}

FString UMysqlResult::getMsg()
{
	return Msg;
}

bool UMysqlResult::getState()
{
	return IsSucceed;
}

int UMysqlResult::getCount()
{
	if (rows.Num() < 1)
	{
		return 0;
	}

	return FCString::Atoi(*rows[0].Value["0"]);
}

int UMysqlResult::getEffectRows()
{
	return effectRows;
}

int UMysqlResult::getInsertId()
{
	return insert_id;
}

TArray<FRow> UMysqlResult::getRows()
{
	return rows;
}
