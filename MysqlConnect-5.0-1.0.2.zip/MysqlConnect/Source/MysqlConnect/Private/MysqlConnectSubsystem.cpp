// Copyright 2021 ShuoDun. All Rights Reserved.

#include "MysqlConnectSubsystem.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "MysqlConnect.h"
#include "Subsystems/SubsystemBlueprintLibrary.h"


UMysqlConnectSubsystem* UMysqlConnectSubsystem::_StaticClass = NULL;			//����ָ��

UMysqlConnectSubsystem::UMysqlConnectSubsystem()
	: UEngineSubsystem()
{
	ResponseJsonObj = NewObject<UMysqlResult>();
	_StaticClass = this;
}

void UMysqlConnectSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

}

void UMysqlConnectSubsystem::Deinitialize()
{
	// Do nothing for now
	Super::Deinitialize();

}

UMysqlConnectSubsystem* UMysqlConnectSubsystem::Get()
{
	return _StaticClass;
}

void UMysqlConnectSubsystem::UseAsync(UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, UMysqlResult*& Results)
{
	// Prepare latent action
	if (UWorld* World = GEngine->GetWorldFromContextObjectChecked(WorldContextObject))
	{
		FLatentActionManager& LatentActionManager = World->GetLatentActionManager();
		FClientLatentAction<UMysqlResult*>* Kont = LatentActionManager.FindExistingAction<FClientLatentAction<UMysqlResult*>>(LatentInfo.CallbackTarget, LatentInfo.UUID);

		if (Kont != nullptr)
		{
			Kont->Cancel();
			LatentActionManager.RemoveActionsForObject(LatentInfo.CallbackTarget);
		}

		LatentActionManager.AddNewAction(LatentInfo.CallbackTarget, LatentInfo.UUID, ContinueAction = new FClientLatentAction<UMysqlResult*>(this, Results, LatentInfo));
	}
}

/////////////////////ͬ��/////////////////////

void UMysqlConnectSubsystem::Close()
{
	Mysql.close();
}

void UMysqlConnectSubsystem::Connect(FString Host, int Port, FString UserName, FString Password, FString DbName, UMysqlResult*& Results)
{
	Mysql.init();

	string tHost(TCHAR_TO_UTF8(*Host));
	string tUserName(TCHAR_TO_UTF8(*UserName));
	string tPassword(TCHAR_TO_UTF8(*Password));
	string tDbName(TCHAR_TO_UTF8(*DbName));

	string _msg;
	if (!Results)
	{
		Results = ResponseJsonObj;
	}

	Results->Reset();
	Results->IsSucceed = Mysql.Connect(tHost, Port, tUserName, tPassword, tDbName, _msg);
	Results->Msg = _msg.c_str();
}

void UMysqlConnectSubsystem::Execute(FString Sql, UMysqlResult*& Results)
{
	string _msg;
	if (!Results)
	{
		Results = ResponseJsonObj;
	}

	Results->Reset();
	Results->IsSucceed = Mysql.Execute(TCHAR_TO_UTF8(*Sql), _msg);
	Results->Msg = _msg.c_str();
}

void UMysqlConnectSubsystem::Insert(FString Sql, UMysqlResult*& Results)
{
	string _msg;
	int ret;
	if (!Results)
	{
		Results = ResponseJsonObj;
	}

	Results->Reset();
	Results->IsSucceed = Mysql.Update(TCHAR_TO_UTF8(*Sql), _msg, ret);
	Results->Msg = _msg.c_str();
	Results->effectRows = ret;

	map<int, map<string, string>> arr;
	Mysql.Query("SELECT LAST_INSERT_ID();", _msg, arr);
	Results->insert_id = atoi(arr[0]["0"].c_str());
}

void UMysqlConnectSubsystem::Update(FString Sql, UMysqlResult*& Results)
{
	string _msg;
	int ret;
	if (!Results)
	{
		Results = ResponseJsonObj;
	}

	Results->Reset();
	Results->IsSucceed = Mysql.Update(TCHAR_TO_UTF8(*Sql), _msg, ret);
	Results->Msg = _msg.c_str();
	Results->effectRows = ret;
}

void UMysqlConnectSubsystem::Delete(FString Sql, UMysqlResult*& Results)
{
	string _msg;
	int ret;
	if (!Results)
	{
		Results = ResponseJsonObj;
	}

	Results->Reset();
	Results->IsSucceed = Mysql.Update(TCHAR_TO_UTF8(*Sql), _msg, ret);
	Results->Msg = _msg.c_str();
	Results->effectRows = ret;
}

void UMysqlConnectSubsystem::Query(FString Sql, UMysqlResult*& Results)
{
	string _msg;
	map<int, map<string, string>> arr;
	if (!Results)
	{
		Results = ResponseJsonObj;
	}

	Results->Reset();
	Results->IsSucceed = Mysql.Query(TCHAR_TO_UTF8(*Sql), _msg, arr);
	Results->Msg = _msg.c_str();

	if (Results->IsSucceed) {
		Results->setRows(arr);
	}
}

////////////////////�첽//////////////////////

void UMysqlConnectSubsystem::AConnect(FString Host, int Port, FString UserName, FString Password, FString DbName, UMysqlResult*& Results, UObject* WorldContextObject, struct FLatentActionInfo LatentInfo)
{
	UseAsync(WorldContextObject, LatentInfo, Results);

	FRunnableThread::Create(new FWorkerThread([this, Host, Port, UserName, Password, DbName]
	{
		Connect(Host, Port, UserName, Password, DbName, ResponseJsonObj);

		// Finish the latent action
		if (ContinueAction)
		{
			FClientLatentAction<UMysqlResult*>* K = ContinueAction;
			ContinueAction = nullptr;

			K->Call(ResponseJsonObj);
		}

		return false;
	}), TEXT("MysqlConnect Connect PollingThread"));
}

void UMysqlConnectSubsystem::AExecute(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject, struct FLatentActionInfo LatentInfo)
{
	UseAsync(WorldContextObject, LatentInfo, Results);

	FRunnableThread::Create(new FWorkerThread([this, Sql]
	{
		Execute(Sql, ResponseJsonObj);

		// Finish the latent action
		if (ContinueAction)
		{
			FClientLatentAction<UMysqlResult*>* K = ContinueAction;
			ContinueAction = nullptr;

			K->Call(ResponseJsonObj);
		}

		return false;
	}), TEXT("MysqlConnect Execute PollingThread"));
}

void UMysqlConnectSubsystem::AInsert(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject, struct FLatentActionInfo LatentInfo)
{
	UseAsync(WorldContextObject, LatentInfo, Results);

	FRunnableThread::Create(new FWorkerThread([this, Sql]
	{
		Insert(Sql, ResponseJsonObj);

		// Finish the latent action
		if (ContinueAction)
		{
			FClientLatentAction<UMysqlResult*>* K = ContinueAction;
			ContinueAction = nullptr;

			K->Call(ResponseJsonObj);
		}

		return false;
	}), TEXT("MysqlConnect Insert PollingThread"));
}

void UMysqlConnectSubsystem::AUpdate(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject, struct FLatentActionInfo LatentInfo)
{
	UseAsync(WorldContextObject, LatentInfo, Results);

	FRunnableThread::Create(new FWorkerThread([this, Sql]
	{
		Update(Sql, ResponseJsonObj);

		// Finish the latent action
		if (ContinueAction)
		{
			FClientLatentAction<UMysqlResult*>* K = ContinueAction;
			ContinueAction = nullptr;

			K->Call(ResponseJsonObj);
		}

		return false;
	}), TEXT("MysqlConnect Update PollingThread"));
}

void UMysqlConnectSubsystem::ADelete(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject, struct FLatentActionInfo LatentInfo)
{
	UseAsync(WorldContextObject, LatentInfo, Results);

	FRunnableThread::Create(new FWorkerThread([this, Sql]
	{
		Delete(Sql, ResponseJsonObj);

		// Finish the latent action
		if (ContinueAction)
		{
			FClientLatentAction<UMysqlResult*>* K = ContinueAction;
			ContinueAction = nullptr;

			K->Call(ResponseJsonObj);
		}

		return false;
	}), TEXT("MysqlConnect Delete PollingThread"));
}

void UMysqlConnectSubsystem::AQuery(FString Sql, UMysqlResult*& Results, UObject* WorldContextObject, struct FLatentActionInfo LatentInfo)
{
	UseAsync(WorldContextObject, LatentInfo, Results);

	FRunnableThread::Create(new FWorkerThread([this, Sql]
	{
		Query(Sql, ResponseJsonObj);

		// Finish the latent action
		if (ContinueAction)
		{
			FClientLatentAction<UMysqlResult*>* K = ContinueAction;
			ContinueAction = nullptr;

			K->Call(ResponseJsonObj);
		}

		return false;
	}), TEXT("MysqlConnect Query PollingThread"));
}
